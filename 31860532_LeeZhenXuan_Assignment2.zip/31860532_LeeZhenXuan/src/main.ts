import { fromEvent, iif, interval, merge, of } from 'rxjs';
import { map, filter, flatMap, scan, takeUntil } from 'rxjs/operators';
import { formatDiagnostic, NumberLiteralType, visitLexicalEnvironment } from 'typescript';
import "./style.css";

//Author: Lee Zhen Xuan 31860532 

type Key = 'ArrowLeft' | 'ArrowRight' | 'ArrowUp' | 'ArrowDown' |'Space'//the type of keys need for movements, and restarting the game
type Event = 'keydown' //an event where a key is pressed down


function main() {
  //the Constants are immutable states/variables to indicate the attributes or state of the objects 
  const Constants = {
    StartCarsCount: 12,
    StartCarsWidth: 40,
    StartCarsHeight: 30,
    StartTime: 0,
    moveAcc: 0.1,
    CanvasSize: 600,
    StartLogsCount: 12,
    StartLogsWidth: 100,
    StartLogsHeight: 30,
    StartFinishCount: 4,
    FinishLength: 50,

    StartTurtleCount: 4,
    StartTurtleWidth: 80,
    
  }

  //the view type for referencing the object
  type ViewType = 'frog' | 'car' | 'log' | 'finish' | 'bug' | 'turtle' | 'alligator'


  class Tick { constructor(public readonly elapsed: number) { } }
  class Move { constructor(public readonly pos: Vec) { } }
  class Restart { constructor(public readonly num: number) { } }

  const
  
  //to "listen" to the keys pressed at a fixed interval
    gameClock = interval(10)
      .pipe(map(elapsed => new Tick(elapsed))),
    keyObservable = <T>(e: Event, k: Key, result: () => T) =>
      fromEvent<KeyboardEvent>(document, e)
        .pipe(
          filter(({ code }) => code === k),
          filter(({ repeat }) => !repeat),

          map(result)),

    //the observables for the keyboard events
    moveLeft$ = keyObservable('keydown', 'ArrowLeft', () => new Move(new Vec(-30, 0))),
    moveRight$ = keyObservable('keydown', 'ArrowRight', () => new Move(new Vec(30, 0))),
    moveUp$ = keyObservable('keydown', 'ArrowUp', () => new Move(new Vec(0, -50))),
    moveDown$ = keyObservable('keydown', 'ArrowDown', () => new Move(new Vec(0, 50))),
    Restart$ = keyObservable('keydown', 'Space', () => new Restart(1))
        
  //indicate a type for all objects related to retangles
  type Rectangle = Readonly<{ pos: Vec, width: number, height: number }>

  //the id for the object
  type ObjectId = Readonly<{ id: string, createTime: number }>

  //an interface to act as a contract or the related classes to follow the needed attributes
  interface IBody extends Rectangle, ObjectId {
    viewType: ViewType,
    id: string,
    pos: Vec,
    vel: Vec,
    createTime: number,
    width: number,
    height: number,
    radius: number,
    color: string,
    dissapear: boolean

  }

  //a type to refer to the different properties and functions that the initialState has
  type State = {
    time: number,
    frog: Body,
    cars: ReadonlyArray<Body>,
    logs: ReadonlyArray<Body>,
    objCount: number,
    gameover: boolean,
    finish: ReadonlyArray<Body>,
    bug: Body,
    bugFrog: boolean
    life: number,
    highscore: number,
    score: number,
    alligator: Body,
    removeTarget: boolean,
    finx: number,
    finy: number,
    target: boolean,
    outoflives: boolean,

  



  }
  type Body = Readonly<IBody>

  //a function to create an instance of a Frog
  function createFrog(): Body {
    return {
      viewType: 'frog',
      id: 'frog',
      pos: new Vec(Constants.CanvasSize / 2, 480),
      vel: new Vec(0, 0),
      createTime: 0,
      radius: 10,
      width: 0,
      height: 0,
      color: "lightgreen",
      dissapear: false,


    }
  }

  //a function to create an instance of a Bug
  function createBug(): Body {
    return {
      viewType: 'bug',
      id: 'bug',
      pos: new Vec(Constants.CanvasSize / 2 + 60, 130),
      vel: new Vec(0, 0),
      createTime: 0,
      radius: 10,
      width: 0,
      height: 0,
      color: "pink",
      dissapear: false,

    }
  }

  //a function to create an instance of a Alligator
  function createalligator(): Body {
    return {
      viewType: 'alligator',
      id: 'bug',
      pos: new Vec(Constants.CanvasSize / 2 - 80, 165),
      vel: new Vec(0, 0),
      createTime: 0,
      radius: 10,
      width: 80,
      height: 20,
      color: "green",
      dissapear: false,

    }
  }




  //a generalised function to create instances related to Rectangles 
  const createRect = (viewType: ViewType) => (oid: ObjectId) => (rect: Rectangle) => (vel: Vec) =>
    <Body>{
      ...oid,
      ...rect,
      vel: vel,
      acc: Vec.Zero,
      id: viewType + oid.id,
      viewType: viewType,
      radius: 0,
      color: "green",
      dissapear: false,
      target: false

    },

    //to create a car, log and the target area instances
    createCar = createRect('car'),
    createLog = createRect('log'),
    createFinish = createRect('finish')


  //to create arrays that store the instances of cars, logs and the target areas
  const
  //an array to create and store cars with their attributes defined
  //the speed and position of each car is related to their position inside the array (i)
    startCars = [...Array(Constants.StartCarsCount)]
      .map((_, i) => createCar({ id: String(i), createTime: Constants.StartTime })
        ({ pos: new Vec(Constants.CanvasSize - (50 * 2.5 * i), (Math.floor(i / 4) + 1) * 50 + 265), width: Constants.StartCarsWidth, height: Constants.StartCarsHeight })
        (new Vec(Math.pow(-0.5, Math.floor(i / 4)) * 1.5, 0))),

  //an array to create and store logs with their attributes defined
  //the speed and position of each log is related to their position inside the array (i)
    startLogs = [...Array(Constants.StartLogsCount)]
      .map((_, i) => createLog({ id: String(i), createTime: Constants.StartTime })
        ({ pos: new Vec(Constants.CanvasSize - ((i * 0.5 + 200 - i * 130)), (Math.floor(i / 3) + 1) * 50 + 13), width: Constants.StartLogsWidth, height: Constants.StartLogsHeight })
        (new Vec(Math.pow(-0.5, Math.floor(i / 3)) * 1.5, 0))),

  //an array to create and store the target areas with their attributes defined
  //the position of each target area is related to their position inside the array (i)
    startFinish = [...Array(Constants.StartFinishCount)]
      .map((_, i) => createFinish({ id: String(i), createTime: Constants.StartTime })
        ({ pos: new Vec(Constants.CanvasSize - (i * 125 + 125)), width: Constants.FinishLength, height: Constants.FinishLength })
        (new Vec(0, 0))),


  //to initialize the initialState of the game 
    initialState: State = {
      time: 0,
      frog: createFrog(),
      cars: startCars,
      logs: startLogs,
      objCount: 0,
      gameover: false,
      finish: startFinish,
      life: 3,
      highscore: 0,
      score: 0,
      bug: createBug(),
      bugFrog: false,
      alligator: createalligator(),
      finx: 0,
      finy: 0,
      target: false,
      removeTarget: false,
      outoflives: false,
      



    },


    //an anonymous function to handle if the the objects get out of the area of the game
    torusWrap = ({ x, y }: Vec) => {
      const s = Constants.CanvasSize,
        wrap = (v: number) => (v < 0 ? v + s : v > s ? v - s : v);
      return new Vec(wrap(x), wrap(y));
    }

  //an anonymous function to move the frog based on its velocity
  const moveFrog = (o: Body, v: Body) => <Body>{
    ...o,
    pos: torusWrap(o.pos.add(v.vel))

  }
  
  //an anonymous function to move the alligators based on its velocity
  const movealligator = (o: Body, v: Vec) => <Body>{
    ...o,
    pos: torusWrap(o.pos.add(v))
  },


  //an anonymous function to move the bugs based on its velocity
  moveBug = (o: Body, v: Vec) => <Body>{
    ...o,
    pos: torusWrap(o.pos.add(v))

  },

  //an anonymous function to move the cars based on its velocity
    moveCar = (o: Body,) => <Body>{
      ...o,
      pos: torusWrap(o.pos.add(o.vel))

    },

  //an anonymous function to move the logs based on its velocity
    moveLog = (o: Body) => <Body>{
      ...o,
      pos: torusWrap(o.pos.add(o.vel)),

    },


  //an anonymous function to handle the collisions between bodies
    handleCollisions = (s: State) => {
      //a function to detect the collision between two bodies
      const bodiesCollided = ([a, b]: [Body, Body]) =>
        Math.abs(a.pos.x - (b.pos.x + b.width / 2)) < (a.radius + b.width / 2) && Math.abs(a.pos.y - (b.pos.y + b.height / 2)) < (a.radius + b.height / 2),

        //a function dedicated to detect the collision between the frog and the bug based on position and size
        bodiesFrogBugCollided = ([a, b]: [Body, Body]) =>
          Math.abs(a.pos.x - (b.pos.x)) < (a.radius + b.radius) && Math.abs(a.pos.y - (b.pos.y + b.radius)) < (a.radius + b.radius),

        //to detect if the frog and another bodies collide
        frogCollided = s.cars.filter((r) =>
          bodiesCollided([s.frog, r])).length > 0,

        //to detect which alligator that a certain body has collided with
        logalligatorCollided = s.logs.filter((r) =>
          bodiesCollided([s.alligator, r])),

        //to detect which bug that a certain body has collided with 
        logBugCollided = s.logs.filter((r) =>
          bodiesCollided([s.bug, r])),

        //to detect if a frog and a bug has collided
        bugFrogCollided = bodiesFrogBugCollided([s.frog, s.bug]),

        //to detect if a bug and a target area has collided
        bugFinishCollided = s.finish.filter((r) =>
          bodiesCollided([s.bug, r])),

        //to detect if a log and a frog has collided
        logFrogCollided = s.logs.filter((r) =>
          bodiesCollided([s.frog, r])),

        //to detect if an alligator and a frog has collided
        alligatorCollided = bodiesCollided([s.frog, s.alligator]),

        //to detect if the frog has reached a target area
        FinishCollided = s.finish.filter((q) =>
        bodiesCollided([s.frog, q]))

      //to detect if the frog has collided with the river in a certain position
      const RiverCollided = logFrogCollided.length <= 0 && s.frog.pos.y < 235 && s.frog.pos.y > 35,


      //to detect if the frog has collided the outside of the target area
        FinishBoundaryCollided = FinishCollided.length <= 0 && s.frog.pos.y < 75


      //to maintain code purity, should not change the state
      //therefore, the code below returns a new state with the new states defined with different values
      return <State>{
        ...s,
        outoflives: s.life<=0,
        //to remove the indicator that the frog has reached the target area
        removeTarget: FinishCollided.length > 0 ? false : s.removeTarget,

        //to indicate if the frog has reached a target area
        target: FinishCollided.length > 0,

        //the x position of the target area that the frog has reached
        finx: FinishCollided.length > 0 ? FinishCollided[0].pos.x + FinishCollided[0].width / 2 : s.finx,

        //the y position of the target area that the frog has reached
        finy: FinishCollided.length > 0 ? FinishCollided[0].pos.y + FinishCollided[0].height / 2 : s.finy,
        
        
        alligator: {
          ...s.alligator,
          //the alligator will follow the log's velocity if it collides with one
          vel: logalligatorCollided.length > 0 ? logalligatorCollided[0].vel : Vec.Zero,
        },

        bug: {
          ...s.bug,
          //if to return the bug after the frog has reached the target area, or to follow the bug 
          pos: s.bugFrog ? s.frog.pos : bugFinishCollided.length > 0 ? new Vec(Constants.CanvasSize / 2 + 60, 130) : s.bug.pos,

          //to follow a log's velocity if the bug has collided with a log
          vel: logBugCollided.length > 0 ? logBugCollided[0].vel : Vec.Zero

        },
        
        bugFrog: bugFrogCollided ? true : FinishCollided.length > 0 ? false : s.bugFrog,

        //to deduct a life if the frog died
        life: s.gameover ? s.life -= 0.5 : s.life,

        //if the score is higher than the highscore, the highscore will be updated to the score
        highscore: s.highscore <= s.score ? s.score : s.highscore,

        //to increase the score by 100 if the frog reached a target area, or 200 if the frog has collected a bug
        score: FinishCollided.length > 0 && s.bugFrog ? s.score += 200 : FinishCollided.length > 0 ? s.score += 100 : s.score,
       

        frog: {
          ...s.frog,
          //the frog will follow a log if the frog has collided with a log
          vel: logFrogCollided.length > 0 ? logFrogCollided[0].vel : Vec.Zero,
          //return the frog to its original position after the frog has died
          pos: FinishCollided.length > 0 || s.gameover ? new Vec(Constants.CanvasSize / 2, 480) : s.frog.pos,
        },
        //to indicate if the frog has died
        gameover: frogCollided || RiverCollided || FinishBoundaryCollided || alligatorCollided,
      }
    }


  const tick = (s: State, elapsed: number) => {
    //to return a new state with the handleCollisions updated
    return handleCollisions({
      ...s,
      //to move the frog based on the frog's velocity
      frog:!s.outoflives? moveFrog(s.frog, s.frog): s.frog,

      //to move the bug based on it's velocity, and the time (moving left and right)
      bug: Math.floor(elapsed / 200) % 2 == 0 ? moveBug(s.bug, s.bug.vel.add(new Vec(0.5, 0))) : moveBug(s.bug, s.bug.vel.add(new Vec(-0.5, 0))),

      //to move each car based on its individual velocity
      cars: s.cars.map(moveCar),

      //to move each log based on its individual velocity
      logs: s.logs.map(moveLog),

      //to move the alligator based on it's velocity, and the time(moving left and right)
      alligator: Math.floor(elapsed / 200) % 2 == 0 ? movealligator(s.alligator, s.alligator.vel.add(new Vec(0.4 * (s.score + 100) / 100, 0))) : movealligator(s.alligator, s.alligator.vel.add(new Vec(-0.4 * (s.score + 100) / 100, 0))),
      //updating the time every tick
      time: elapsed,

    })
  }


  const reduceState = (s: State, e: Move | Tick) =>
    
  //to detect if an instance of move (user arrow movements) have been instantiated to move the frog
    e instanceof Move? {
      ...s,
      frog:!s.outoflives?{ ...s.frog, pos: s.frog.pos.add(e.pos) }: s.frog
    } :
    //to detect if an instance of restart have been instantiated to restart the game, and return a new state except for the highscore
      e instanceof Restart ? {
        ...s,
        time: 0,
        frog: createFrog(),
        cars: startCars,
        logs: startLogs,
        objCount: 0,
        gameover: false,
        finish: startFinish,
        life: 3,
        score: 0,
        bug: createBug(),
        bugFrog: false,
        alligator: createalligator(),

        finx: 0,
        finy: 0,
        target: false,
        removeTarget: true,
        outoflives: false
      } :
        tick(s, e.elapsed)


  const subscription =
    merge(gameClock,
      moveLeft$, moveRight$, moveUp$, moveDown$, Restart$).pipe(
        scan(reduceState, initialState))
      .subscribe(updateView)
  //to update the view of the user
  function updateView(s: State) {
    const
    //to reference the elements based on their id
      svg = document.getElementById("svgCanvas")!,
      frog = document.getElementById("frog")!,
      bug = document.getElementById("bug")!,
      alligator = document.getElementById("alligator")!,

    
      updateBodyView = (b: Body) => {

        document.getElementById("lives").innerHTML = "Lives: " + s.life.toString()
        document.getElementById("hs").innerHTML = "High-Score: " + s.highscore.toString()
        document.getElementById("score").innerHTML = "Score: " + s.score.toString()

        function createBodyView() {
          //to append the rectangles, and declare their attributes
          const v = document.createElementNS(svg.namespaceURI, "rect")!;
          attr(v, { id: b.id, width: b.width, height: b.height, fill: b.color });
          v.classList.add(b.viewType)
          svg.appendChild(v)
          return v;
        }
        const v = document.getElementById(b.id) || createBodyView();
        attr(v, { x: b.pos.x, y: b.pos.y });
      };
    //updating the position of the frog, bug and alligator
    attr(frog, { transform: `translate(${s.frog.pos.x},${s.frog.pos.y})` });
    attr(bug, { transform: `translate(${s.bug.pos.x},${s.bug.pos.y})` });
    attr(alligator, { transform: `translate(${s.alligator.pos.x},${s.alligator.pos.y})` });
    s.cars.forEach(updateBodyView)
    s.logs.forEach(updateBodyView)
    s.finish.forEach(updateBodyView)

    //to remove the indicator of the frog that has reached the target area
    if(!s.outoflives && document.getElementById("gameover")!= null){
      svg.removeChild(document.getElementById("gameover"))
    }
    if (s.removeTarget && document.getElementById("z") != null) {
      svg.removeChild(document.getElementById("z"))
    }

    //if the frog has reached a target area, create a circle at the target area
    if (s.target) {

      const z = document.createElementNS(svg.namespaceURI, "circle")!;
      attr(z, { id: "z", r: 20, fill: "red", cx: s.finx, cy: s.finy });
      z.classList.add("finished")
      svg.appendChild(z)

      return z;

    }
    

    //if the frog is out of lives, the game ends
    if (s.life <= 0) {
      
      
      const v = document.createElementNS(svg.namespaceURI, 'text')!;
      attr(v, {
        id: "gameover",
        x: Constants.CanvasSize / 6,
        y: Constants.CanvasSize / 2,
        class: 'gameover',
      });
      v.textContent = 'Game Over';
      svg.appendChild(v);
    }
    svg.appendChild(frog)
    svg.appendChild(bug)
    svg.appendChild(alligator)
  }
}


class Vec {
  constructor(public readonly x: number = 0, public readonly y: number = 0) { }
  add = (b: Vec) => new Vec(this.x + b.x, this.y + b.y)
  static Zero = new Vec();
}
const
  attr = (e: Element, o: Object) => { for (const k in o) e.setAttribute(k, String(o[k])) }

// The following simply runs your main function on window load.  Make sure to leave it in place.
if (typeof window !== "undefined") {
  window.onload = () => {
    main();
  };
}
