module LambdaParser where

import Parser
import Data.Lambda
import Data.Builder
import           Data.Char                      ( isAlpha
                                                , isDigit
                                                , isLower
                                                , isSpace
                                                , isUpper)

-- You can add more imports if you need them

-- Remember that you can (and should) define your own functions, types, and
-- parser combinators. Each of the implementations for the functions below
-- should be fairly short and concise.


{-|
    Part 1
-}

-- | Exercise 1

-- BNF Grammar 
-- <lambda>      ::= "\\"
-- <dot>         ::= "."
-- <symbol>      ::= [a-z] | [A-Z] | [a-z] <symbol> | [A-Z] <symbol> | "("  <symbol>  ")" 
-- <chainingBodiesLong> ::= <functionBodiesLong> <functionBodiesLong> | <functionBodiesLong>
-- <lambdaExpressionLong> ::= <lambda> <symbol> <dot> <chainingBodiesLong> 
-- <bracketLambdaExpressionLong> ::= "(" <lambdaExpressionLong> ")"
-- <bracketFunctionBodiesLong> ::= "(" <chainingBodiesLong> ")"
-- <functionBodiesLong> ::= <lambdaExpressionLong> | <symbol> | <bracketFunctionBodiesLong> | <bracketLambdaExpressionLong>



-- | Parses a string representing a lambda calculus expression in long form
--
-- >>> parse longLambdaP "(λx.xx)"
-- Result >< \x.xx
--
-- >>> parse longLambdaP "(λx.(λy.xy(xx)))"
-- Result >< \xy.xy(xx)
--
-- >>> parse longLambdaP "(λx(λy.x))"
-- UnexpectedChar '('
chain :: Parser a -> Parser (a->a->a) -> Parser a
chain p op = p >>= rest
   where
   rest a = (do
               f <- op
               b <- p
               rest (f a b)
            ) ||| pure a

longLambdaP :: Parser Lambda
longLambdaP = build <$> chainingBodiesLong

chainingBodiesLong :: Parser Builder
chainingBodiesLong = chain functionBodiesLong (pure ap)

functionBodiesLong :: Parser Builder
functionBodiesLong = lambdaExpressionLong ||| termSymbol ||| bracketFunctionBodiesLong ||| bracketLambdaExpressionLong

lambda :: Parser Char
lambda = is 'λ'

dot :: Parser Char
dot = is '.'

openBracket :: Parser Char
openBracket = is '('

closeBracket :: Parser Char
closeBracket = is ')'

symbol :: Parser Char
symbol = satisfy isAlpha

termSymbol :: Parser Builder
termSymbol = term <$> symbol


lambdaExpressionLong :: Parser Builder
lambdaExpressionLong = do
    lambda
    x <- symbol
    dot
    lam x <$> chainingBodiesLong

bracketLambdaExpressionLong :: Parser Builder
bracketLambdaExpressionLong = do
    openBracket
    x <- lambdaExpressionLong
    closeBracket
    pure x


bracketFunctionBodiesLong :: Parser Builder
bracketFunctionBodiesLong = do
    openBracket
    x <- chainingBodiesLong
    closeBracket
    pure x




-- | Parses a string representing a lambda calculus expression in short form
--
-- >>> parse shortLambdaP "λx.xx"
-- Result >< \x.xx
--
-- >>> parse shortLambdaP "λxy.xy(xx)"
-- Result >< \xy.xy(xx)

--
-- >>> parse shortLambdaP "λx.x(λy.yy)"
-- Result >< \x.x\y.yy
--
-- >>> parse shortLambdaP "(λx.x)(λy.yy)"
-- Result >< (\x.x)\y.yy
--
-- >>> parse shortLambdaP "λxyz"
-- UnexpectedEof

shortLambdaP :: Parser Lambda
shortLambdaP = build <$> chainingBodiesShort

chainingBodiesShort :: Parser Builder
chainingBodiesShort = chain functionBodiesShort (pure ap)

functionBodiesShort :: Parser Builder
functionBodiesShort = lambdaExpressionShort ||| termSymbol ||| bracketFunctionBodiesShort ||| bracketLambdaExpressionShort

lambdaExpressionShort :: Parser Builder
lambdaExpressionShort = do
    lambda
    x <- list1 symbol
    dot
    lambdaR x
    where
        lambdaR [] = chainingBodiesShort
        lambdaR (x:xs) = lam x <$> lambdaR xs 

bracketLambdaExpressionShort :: Parser Builder
bracketLambdaExpressionShort = do
    openBracket
    x <- lambdaExpressionShort
    closeBracket
    pure x


bracketFunctionBodiesShort :: Parser Builder
bracketFunctionBodiesShort = do
    openBracket
    x <- chainingBodiesShort
    closeBracket
    pure x



-- | Parses a string representing a lambda calculus expression in short or long form
-- >>> parse lambdaP "λx.xx"
-- Result >< \x.xx
--
-- >>> parse lambdaP "(λx.xx)"
-- Result >< \x.xx
--
-- >>> parse lambdaP "λx..x"
-- UnexpectedChar '.'
--

lambdaP :: Parser Lambda
lambdaP = shortLambdaP ||| longLambdaP


{-|
    Part 2
-}

-- | Exercise 1

-- IMPORTANT: The church encoding for boolean constructs can be found here -> https://tgdwyer.github.io/lambdacalculus/#church-encodings

-- | Parse a logical expression and returns in lambda calculus

-- Just True == lamToBool (build $ boolToLam True)
-- >>> lamToBool <$> parse logicP "True and False"
-- Result >< Just False
--


-- >>> lamToBool <$> parse logicP "True and False or not False and True"
-- Result >< Just True
--
-- >>> lamToBool <$> parse logicP "not not not False"
-- Result >< Just True
--
-- >>> parse logicP "True and False"
-- Result >< (\xy.(\btf.btf)xy\_f.f)(\t_.t)\_f.f
--
-- >>> parse logicP "not False"
-- Result >< (\x.(\btf.btf)x(\_f.f)\t_.t)\_f.f
-- >>> lamToBool <$> parse logicP "if True and not False then True or True else False"
-- Result >< Just True
 


ifOperator :: Builder
ifOperator = lam 'b' $ lam 't' $ lam 'f' ((term 'b') `ap` (term 't') `ap` (term 'f'))

ifOperator1 :: Builder -> Builder -> Builder -> Builder
ifOperator1 x y z = (lam 'b' $ lam 't' $ lam 'f' ((term 'b') `ap` (term 't') `ap` (term 'f'))) `ap` x `ap` y `ap` z

andString :: Parser String
andString = string "and"

andOperator :: Builder -> Builder -> Builder
andOperator x y = (lam 'x' $ lam 'y' $ ifOperator `ap` (term 'x') `ap` term 'y' `ap` boolToLam False) `ap` x `ap` y 
   
orString :: Parser String
orString = string "or"

orOperator :: Builder -> Builder -> Builder
orOperator x y = (lam 'x' $ lam 'y' $ ifOperator `ap` (term 'x') `ap` boolToLam True `ap` term 'y') `ap` x `ap` y

notString :: Parser String
notString = string "not"

notOperator :: Builder 
notOperator  = lam 'x' $ ifOperator `ap` (term 'x') `ap` boolToLam False `ap` boolToLam True

trueString :: Parser String
trueString = string "True"

trueOperator :: Parser Builder
trueOperator = do
    trueString
    pure $ boolToLam True

falseString :: Parser String
falseString = string "False"

falseOperator :: Parser Builder
falseOperator =do 
    falseString
    pure $ boolToLam False


trueFalse :: Parser Builder
trueFalse = trueOperator ||| falseOperator ||| notArguments ||| digit

operatorS :: Parser (Builder -> Builder -> Builder)
operatorS = andArguments ||| orArguments 



notArguments :: Parser Builder
notArguments = do
    spaces
    notString 
    spaces
    x <- trueFalse
    pure $ notOperator `ap` x

andArguments :: Parser (Builder -> Builder -> Builder)
andArguments = do
    spaces
    andString
    spaces
    pure $ andOperator


orArguments :: Parser (Builder -> Builder -> Builder)
orArguments = do
    spaces
    orString
    spaces
    pure $ orOperator

chainingArguments :: Parser Builder
chainingArguments = chain trueFalse (pure ap)

chainingOperators :: Parser Builder
chainingOperators = chain chainingArguments (operatorS)

finalExpression :: Parser Builder 
finalExpression = chainingOperators ||| ifArguments

logicP :: Parser Lambda
logicP= build <$> finalExpression

ifString :: Parser String 
ifString = string "if"

thenString :: Parser String 
thenString = string "then"

elseString :: Parser String 
elseString = string "else"

ifArguments :: Parser Builder
ifArguments = do
    spaces 
    ifString
    spaces
    x <- chainingOperators
    spaces
    thenString 
    spaces
    y <- chainingOperators
    spaces 
    elseString 
    spaces
    z <- chainingOperators 
    spaces
    pure $ ifOperator1 x y z 








-- | Exercise 2

-- | The church encoding for arithmetic operations are given below (with x and y being church numerals)

-- | x + y = add = λxy.y succ m
-- | x - y = minus = λxy.y pred x
-- | x * y = multiply = λxyf.x(yf)
-- | x ** y = exp = λxy.yx



-- | The helper functions you'll need are:
-- | succ = λnfx.f(nfx)
-- | pred = λnfx.n(λgh.h(gf))(λu.x)(λu.u)
-- | Note since we haven't encoded negative numbers pred 0 == 0, and m - n (where n > m) = 0

-- | Parse simple arithmetic expressions involving + - and natural numbers into lambda calculus
-- >>> lamToInt <$> parse basicArithmeticP "5 + 4"
-- Result >< Just 9
--
-- >>> lamToInt <$> parse basicArithmeticP "5 + 9 - 3 + 2"
-- Result >< Just 13
basicArithmeticP :: Parser Lambda
basicArithmeticP = build <$> chainingArith

digit :: Parser Builder
digit = do
    x <- list1 $ satisfy isDigit
    pure $ intToLam (read x)

succOperator :: Builder 
succOperator = lam 'n' $ lam 'f' $ lam 'x'  $(term 'f') `ap` ((term 'n') `ap` (term 'f') `ap` (term 'x')) 

predOperator :: Builder 
predOperator = lam 'n' $ lam 'f' $ lam 'x' $ term 'n' `ap` (lam 'g' $ lam 'h'$ term 'h' `ap` (term 'g' `ap` term 'f')) `ap` (lam 'u' $ term 'x') `ap` (lam 'u' $ term 'u')

addOperator :: Builder -> Builder -> Builder
addOperator x y = (lam 'x' $ lam 'y' $ term 'y' `ap` (succOperator ) `ap` (term 'x')) `ap` x `ap` y

minusOperator :: Builder -> Builder -> Builder
minusOperator x y =  (lam 'x' $ lam 'y' $ term 'y' `ap` (predOperator ) `ap` (term 'x')) `ap` x `ap` y

expOperator :: Builder -> Builder -> Builder 
expOperator x y  = (lam 'x' $ lam 'y' $ (term 'y')  `ap` term 'x') `ap` x `ap` y 


addString :: Parser Char
addString = is '+' 

addArguments :: Parser (Builder -> Builder -> Builder)
addArguments = do
    spaces
    addString
    spaces
    pure $ addOperator

minusString :: Parser Char
minusString = is '-'

minusArguments :: Parser (Builder -> Builder -> Builder)
minusArguments = do 
    spaces
    minusString
    spaces
    pure minusOperator

operatorArith :: Parser (Builder -> Builder -> Builder)
operatorArith = addArguments ||| minusArguments

chainingArith :: Parser Builder
chainingArith = chain digit (operatorArith)


-- | Parse arithmetic expressions involving + - * ** () and natural numbers into lambda calculus
-- >>> lamToInt <$> parse arithmeticP "5 + 9 * 3 - 2**3"
-- Result >< Just 24
--
-- >>> lamToInt <$> parse arithmeticP "100 - 4 * 2**(4-1)"
-- Result >< Just 68
arithmeticP :: Parser Lambda
arithmeticP = build <$> chainingPlusMinus

multiplyOperator :: Builder -> Builder -> Builder
multiplyOperator x y = (lam 'x' $ lam 'y' $ lam 'f'  $(term 'x') `ap` ((term 'y') `ap` (term 'f'))) `ap` x `ap` y

multiplyString ::Parser Char
multiplyString = is '*'

expString :: Parser String
expString = string "**"

expArguments :: Parser (Builder -> Builder -> Builder)
expArguments = do
    spaces 
    expString 
    spaces
    pure $ expOperator

multiplyArguments :: Parser (Builder -> Builder -> Builder)
multiplyArguments = do
    spaces
    multiplyString
    spaces
    pure $ multiplyOperator

digitorBracket :: Parser Builder
digitorBracket = digit ||| bracketOperator ||| trueFalse

chainExp :: Parser Builder 
chainExp = chain digitorBracket (expArguments)

chainMultiply :: Parser Builder
chainMultiply = chain chainExp (multiplyArguments)

chainingPlusMinus :: Parser Builder
chainingPlusMinus = chain chainMultiply (operatorArith)

leftBracket :: Parser Char
leftBracket = is '('

rightBracket :: Parser Char
rightBracket = is ')'

bracketOperator :: Parser Builder
bracketOperator = do
    leftBracket
    x <- chainingPlusMinus
    spaces
    rightBracket
    pure $ x


-- | Exercise 3

-- | The church encoding for comparison operations are given below (with x and y being church numerals)

-- | x <= y = LEQ = λmn.isZero (minus m n)
-- | x == y = EQ = λmn.and (LEQ m n) (LEQ n m)


-- | The helper function you'll need is:
-- | isZero = λn.n(λx.False)True
-- | isOne = λn.n.(λx.False)f True

-- >>> lamToBool <$> parse complexCalcP "9 - 2 <= 3 + 6"
-- Result >< Just True
--
-- >>> lamToBool <$> parse complexCalcP "15 - 2 * 2 != 2**3 + 3 or 5 * 3 + 1 < 9"
-- Result >< Just False
complexCalcP :: Parser Lambda
complexCalcP = build <$> (chainAON ||| finalExpression)

minusOp :: Builder 
minusOp = (lam 'x' $ lam 'y' $ term 'y' `ap` (predOperator ) `ap` (term 'x'))

isZero :: Builder
isZero = lam 'n' $ term 'n' `ap` (lam 'x' $ (boolToLam False)) `ap` (boolToLam True) 

lessThanOrEqualOperator :: Builder -> Builder -> Builder
lessThanOrEqualOperator x y = (lam 'm' $ lam 'n' (isZero `ap` minusOperator (term 'm') (term 'n') )) `ap` x `ap` y

equalOperator :: Builder -> Builder -> Builder
equalOperator x y = (lam 'm' $ lam 'n' (andOperator (lessThanOrEqualOperator  (term 'm') (term 'n')) (lessThanOrEqualOperator  (term 'n') (term 'm')))) `ap` (x) `ap` (y)

notEqualsOperator :: Builder -> Builder -> Builder
notEqualsOperator x y = (lam 'm' $ lam 'n' (notOperator `ap` (andOperator (lessThanOrEqualOperator  (term 'm') (term 'n')) (lessThanOrEqualOperator  (term 'n') (term 'm'))))) `ap` x `ap` y

moreThanOrEqualOperator :: Builder -> Builder -> Builder
moreThanOrEqualOperator x y = (lam 'n' $ lam 'm' (isZero `ap` minusOperator (term 'n') (term 'm') )) `ap` y `ap` x

lessThanOperator :: Builder -> Builder -> Builder
lessThanOperator x y = (lam 'n' $ lam 'm' (notOperator `ap` (isZero `ap` minusOperator (term 'n') (term 'm') ))) `ap` y `ap` x

moreThanOperator :: Builder -> Builder -> Builder
moreThanOperator x y = (lam 'm' $ lam 'n' (notOperator `ap` (isZero `ap` minusOperator (term 'm') (term 'n') ))) `ap` x `ap` y


lEQString :: Parser String
lEQString = string "<="

eQString :: Parser String
eQString = string "=="

notEqString :: Parser String 
notEqString = string "!="

mEQString :: Parser String
mEQString = string ">="

lessString :: Parser String
lessString = string "<"

moreString :: Parser String 
moreString = string ">"

moreArgument :: Parser (Builder -> Builder -> Builder)
moreArgument = do
    spaces
    moreString 
    spaces 
    pure $ moreThanOperator

lessArgument :: Parser (Builder -> Builder -> Builder)
lessArgument = do
    spaces
    lessString 
    spaces 
    pure $ lessThanOperator

lEQArgument :: Parser (Builder -> Builder -> Builder)
lEQArgument = do
    spaces
    lEQString 
    spaces 
    pure $ lessThanOrEqualOperator

mEQArgument :: Parser (Builder -> Builder -> Builder)
mEQArgument = do
    spaces
    mEQString 
    spaces 
    pure $ moreThanOrEqualOperator

eQArgument :: Parser (Builder -> Builder -> Builder)
eQArgument = do
    spaces
    eQString
    spaces
    pure $ equalOperator

notEqArgument :: Parser (Builder -> Builder -> Builder)
notEqArgument = do
    spaces
    notEqString 
    spaces
    pure $ notEqualsOperator

operatorAON :: Parser (Builder -> Builder -> Builder)
operatorAON = andArguments ||| orArguments 

complexOperators :: Parser (Builder -> Builder -> Builder)
complexOperators = lEQArgument ||| eQArgument ||| notEqArgument ||| mEQArgument ||| lessArgument ||| moreArgument 

chainLEQ :: Parser Builder 
chainLEQ = chain chainingPlusMinus (complexOperators) 

chainAON :: Parser Builder
chainAON = chain chainLEQ (operatorAON)

{-|
    Part 3
-}

-- | Exercise 1

-- | The church encoding for list constructs are given below
-- | [] = null = λcn.n
-- | isNull = λl.l(λht.False) True
-- | cons = λhtcn.ch(tcn)
-- | head = λl.l(λht.h) False
-- | tail = λlcn.l(λhtg.gh(tc))(λt.n)(λht.t)
--
-- >>> parse listP "[]"
-- Result >< \cn.n
--



lB :: Parser Char
lB = is '['

rB :: Parser Char
rB = is ']'

comma :: Parser Char
comma = is ','

bracket :: Builder
bracket = lam 'c' $ lam 'n' $ term 'n'

cons :: Builder 
cons = lam 'h' $ lam 't' $ lam 'c' $ lam 'n'  $(term 'c') `ap` (term 'h') `ap` ((term 't') `ap` (term 'c') `ap` (term 'n'))

commaArgument :: Builder -> Builder -> Builder
commaArgument x y = x `ap` y

elementList :: Parser Builder 
elementList = do
    x <- allChains
    pure $ cons `ap` x

chainingElements :: Parser Builder
chainingElements = chain elementList (commaOperator)

allChains :: Parser Builder
allChains = chainingOperators ||| chainingPlusMinus ||| finalExpression

commaOperator :: Parser (Builder -> Builder -> Builder)
commaOperator = do
    spaces
    comma
    spaces
    pure $ commaArgument

listPArguments :: Parser Builder
listPArguments = listOperator ||| listOperatorNull

listOperator :: Parser Builder
listOperator = do
    lB
    spaces
    x <- chainingElements
    spaces
    rB
    pure $ x `ap` bracket

listOperatorNull :: Parser Builder
listOperatorNull = do
    lB
    spaces
    rB
    pure $ bracket
    



-- >>> parse listP "[True]"
-- Result >< (\htcn.ch(tcn))(\xy.x)\cn.n
--
-- >>> parse listP "[0, 0]"
-- Result >< (\htcn.ch(tcn))(\fx.x) ((\htcn.ch(tcn))(\fx.x)\cn.n)
--
-- >>> parse listP "[0, 0"
-- UnexpectedEof
listP :: Parser Lambda
listP = build <$> listPArguments


-- | head = λl.l(λht.h) False
-- | tail = λlcn.l(λhtg.gh(tc))(λt.n)(λht.t)
headList:: Builder 
headList = lam 'l' $ term 'l' `ap` (lam 'h' $ lam 't' $ term 'h' ) `ap` (boolToLam False)

tailList :: Builder
tailList = lam 'l' $ lam 'c' $ lam 'n' $ term 'l' `ap` (lam 'h' $ lam 't' $ lam 'g' $ term 'g' `ap` term 'h' `ap` (term 't' `ap` term 'c') ) `ap` (lam 't' $ term 'n') `ap` (lam 'h' $ lam 't' $ term 't')

-- | isNull = λl.l(λht.False) True



headString :: Parser String
headString = string "head"

headArgument :: Parser (Builder)  
headArgument = do 
    spaces 
    headString 
    spaces
    x <- listPArguments
    spaces
    pure $ headList `ap` x


tailString :: Parser String 
tailString = string "tail"

tailArgument = do
    spaces 
    tailString 
    spaces 
    x <- listPArguments
    spaces
    pure $ tailList `ap` x

-- >>> lamToBool <$> parse listOpP "head [True, False, True, False, False]"
-- Result >< Just True
--
-- >>> lamToBool <$> parse listOpP "head rest [True, False, True, False, False]"
-- Result >< Just False
--
-- >>> lamToBool <$> parse listOpP "isNull []"
-- Result >< Just True
--
-- >>> lamToBool <$> parse listOpP "isNull [1, 2, 3]"
-- Result >< Just False
listOpP :: Parser Lambda
listOpP = build <$> headArgument



-- | Exercise 2

-- | Implement your function(s) of choice below!
stepRecursion:: Builder
stepRecursion = lam 'f' $ lam 'n' $ (isZero `ap` term 'n') `ap` (intToLam 1) `ap` multiplyOperator (term 'n') (term 'f' `ap` (predOperator `ap` term 'n'))


factorial :: Builder 
factorial  = (lam 'x'( (lam 'y'$ term 'x' `ap` (term 'y' `ap` term 'y')) `ap` ((lam 'y'$ term 'x' `ap` (term 'y' `ap` term 'y'))))) `ap` (stepRecursion)

factorialString :: Parser Char
factorialString = is '!'

factorialArgument :: Parser Builder
factorialArgument = do
    spaces 
    x <- chainAON 
    spaces
    factorialString 
    spaces
    pure $ factorial `ap` x

buildFactorial :: Parser Lambda
buildFactorial = build <$> factorialArgument


